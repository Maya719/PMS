<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LanguageLoaderHook {

    function LoadLanguage() {
        $ci =& get_instance();
        $lang = $ci->session->userdata('lang');
        if($lang){
            $ci->lang->load('custom_labels',$lang);
        }else{
            $ci->lang->load('custom_labels','english');
        }
    }

}
