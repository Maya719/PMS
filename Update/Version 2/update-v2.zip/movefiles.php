<?php
$movepaths = array('application/controllers/Settings.php');
?>