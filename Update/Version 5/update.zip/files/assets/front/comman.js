"use strict";

$('.cookie-bar-btn').on('click', function () {
    localStorage.setItem('cookie-wap', '1');
    $('#cookie-bar').fadeOut();
});

if (localStorage.getItem('cookie-wap') != '1') {
    $('#cookie-bar').delay(2000).fadeIn();
}

$("#front_contact_form").submit(function(e) {
    e.preventDefault();
    var $this = $(this);
    let save_button = $(this).find('.savebtn'),
    output_status = $(this).find('.result');
    save_button.addClass('disabled');
    output_status.html('');
    if(site_key){
        grecaptcha.ready(function() {
            grecaptcha.execute(site_key, {action: 'contact_form'}).then(function(token) {
                $($this).prepend('<input type="hidden" name="token" value="' + token + '">');
                $($this).prepend('<input type="hidden" name="action" value="contact_form">');
                var formData = new FormData(document.getElementById("front_contact_form"));
                output_status.show(); 
                $.ajax({
                    type:'POST',
                    url: $($this).attr('action'),
                    data:formData,
                    cache:false,
                    contentType: false,
                    processData: false,
                    dataType: "json",
                    success:function(result){
                        if(result['error'] == false){
                            output_status.prepend('<div class="alert alert-success">'+result['message']+'</div>');
                        }else{
                            output_status.prepend('<div class="alert alert-danger">'+result['message']+'</div>');
                        }
                        output_status.delay(4000).fadeOut();    
                        save_button.removeClass('disabled'); 
                    }
                });
            });
        });
    }else{
        var formData = new FormData(document.getElementById("front_contact_form"));
        $.ajax({
            type:'POST',
            url: $($this).attr('action'),
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            dataType: "json",
            success:function(result){
                if(result['error'] == false){
                    output_status.prepend('<div class="alert alert-success">'+result['message']+'</div>');
                }else{
                    output_status.prepend('<div class="alert alert-danger">'+result['message']+'</div>');
                }
                output_status.find('.alert').delay(4000).fadeOut();    
                save_button.removeClass('disabled'); 
            }
        });
    }
});

